package com.example.lession15springbootthymeleaf_case;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lession15SpringbootThymeleafCaseApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lession15SpringbootThymeleafCaseApplication.class, args);
    }

}

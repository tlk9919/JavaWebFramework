package com.example.lession15springbootthymeleaf_case.service;

import com.example.lession15springbootthymeleaf_case.model.Student;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author admin_tlk
 * @since 2024-12-02
 */
public interface IStudentService extends IService<Student> {

}

package com.example.lession15springbootthymeleaf_case;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lession15SpringbootThymeleafCaseApplicationTests {

    @Test
    void contextLoads() {
    }

}

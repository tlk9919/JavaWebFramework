package com.example.starwhisper_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StarWhisperServerApplicationTests {

    @Test
    void contextLoads() {
    }

}
